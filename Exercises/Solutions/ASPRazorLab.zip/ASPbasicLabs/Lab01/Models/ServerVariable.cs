﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab01.Models
{
    public class ServerVariable
    {
        public String key { get; set; }
        public String value { get; set; }
    }
}