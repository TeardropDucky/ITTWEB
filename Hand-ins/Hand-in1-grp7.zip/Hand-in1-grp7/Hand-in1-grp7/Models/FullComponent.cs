﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hand_in1_grp7.Models
{
    public class FullComponent
    {
        public List<Component> Components { get; set; }
        public ComponentInformation ComponentInfo {get; set;}
    }
}